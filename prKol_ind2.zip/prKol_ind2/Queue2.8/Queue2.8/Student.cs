﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue2._8
{
    class Student
    {
        public string name1;
        public string name2;
        public string name3;
        public string gr;
        public int mark1;
        public int mark2;
        public int mark3;
    }
}
